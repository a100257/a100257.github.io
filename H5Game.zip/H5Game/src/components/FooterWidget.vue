<template>
  <div class="p-7 text-center text-sm text-white">
    <p class="mt-3">
      <LinkWidget href="/about">About</LinkWidget> ·
      <LinkWidget href="/privacy">Privacy</LinkWidget>
    </p>
  </div>
</template>
