<template>
  <a>
    <slot></slot>
  </a>
</template>
