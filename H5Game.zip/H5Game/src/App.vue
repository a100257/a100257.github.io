<script setup>
import { RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>

<style>
  #app, body, html {
    width: 100%;
    height: 100%;
    box-sizing: border-box;
  }
</style>
